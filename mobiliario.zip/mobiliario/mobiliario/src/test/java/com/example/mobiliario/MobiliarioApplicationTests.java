package com.example.mobiliario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobiliarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
